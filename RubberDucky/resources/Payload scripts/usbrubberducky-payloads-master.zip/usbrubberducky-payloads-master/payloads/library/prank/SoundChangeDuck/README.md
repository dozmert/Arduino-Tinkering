**Title: SoundChangeDuck**

<p>Author: 0iphor13<br>
OS: Windows<br>
Version: 1.0</p>

**What is SoundChangeDuck?**
<p>Nothing special... SoundChangeDuck changes the systems sound of device connection.<br>
In this example it changes the sound from Hardware Insert to Hardware Fail - You can of course decide which sounds you want to change.<br>
Also feel free to bring your own .wav file to use custom sounds.</p>
