# Rick Updater
A simple script that will load a fake Windows 10 update screen, and begin to rick roll the target at 100% volume and will continuously raise the volume back to 100% everytime you change it.
