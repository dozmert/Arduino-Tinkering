# The Penny Drops
* Author: Cribbit 
* Version: 1.0
* Target: any
* Category: General
* Attackmode: HID
* Props: Darren & Korben

## Change Log
| Version | Changes                       |
| ------- | ------------------------------|
| 1.0     | Initial release               |

## Description
Little arcade coin drop / pachinko style game

```
 _(PENNY)_ 
/    0    \
|    .    |
|   . .   |
|  . . .  |
| . . . . |
| | | | | |
|1|2|5|2|1|
```

## Getting Started

Open a text editor then insert the ducky.

